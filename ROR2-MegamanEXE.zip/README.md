# Overview
Megaman EXE as a survivor for Risk Of Rain 2: Jack-in Megaman!

# Installation Instructions:
Place the DLL file in your plugins folder or extract it to a folder inside plugins.

# Screenshots
![](https://i.imgur.com/lKsRPB8.png)
![](https://i.imgur.com/C6Xuiei.png)
![](https://i.imgur.com/ve5qV6S.png)
![](https://i.imgur.com/EfMejb1.png)

# Changelog
- V 1.0.0 Posted
- V 1.0.2 Fixed bug on CheckDMG hook

# Special Thanks
- The RoR2 Modding Community
- My Friends
- My Family

# Donations
- Please remember that this mod is FREE and will always be. I made it hoping that you would enjoy and have fun!

- But if you are feeling generous to pay me a coffee, click >  <a href='https://ko-fi.com/M4M1LVGAO' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi1.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>


# CREDITS
- MEGAMAN EXE CYBER SWORD MODEL CREDITS!!!
- https://gamebanana.com/requests/29756?fbclid=IwAR0BdplKt7PvvNxREKnSCvTcrwikCTdCMYcTC_erPFFg3AEFrr_mne2u8r4